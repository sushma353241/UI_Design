class switchdemo{
	void Sdemo(String name){
		switch(name){
			case 'apple'||'Apple'||'APPLE':
				print("apple is listed");
			case 'banana'||'Banana'||'BANANA':
				print("Banana is listed");
			case 'cherry'||'Cherry'||'CHERRY':
				print("Cherry is listed");

			default:
				print("This fruit is not listed");
		}
	}
}