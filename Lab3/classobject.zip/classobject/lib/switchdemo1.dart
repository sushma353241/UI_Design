class switchdemo1{
	void Sdemo1(String name){
		switch(name){
			case 'apple':
				print("apple is listed");
			case 'banana':
				print("Banana is listed");
			case 'cherry':
				print("Cherry is listed");

			default:
				print("This fruit is not listed");
		}
	}
}