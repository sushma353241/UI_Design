class switchdemo2 {
  void Sdemo2(String name) {
    outerLoop: while (true) {
      switch (name) {
        case "Apple":
          print("Apple is listed");
          name = "End";           
	  continue outerLoop;

        case "apple":
          print("apple is listed");
          break;

        case "banana":
          print("Banana is listed");
          break;

        case "cherry":
          print("Cherry is listed");
          break;

        default:
          print("This fruit is not listed");
      }
      break; 
    }
  }
}
