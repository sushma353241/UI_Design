class switchdemo{
String Scase(String color){
	return (switch(color){
		'red'||'Red'||'RED' 	=> "This is red",
		'blue'||'Blue'||'BLUE'  => 'This is blue',
		'green'||'Green'||'GREEN'=> 'This is green',
		'yellow'||'Yellow'||'YELLOW'=>'This is yellow',
		 		_ 	=> 'Not listed',
	});
	print(color);
	}
}